package com.mani.session4ass4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sakshi.banger on 02-09-2016.
 */
public class GridViewAdapter extends BaseAdapter {
    Context mcontext;
    int image[]={R.drawable.gingerbread,R.drawable.honeycomb,R.drawable.icecream,R.drawable.jellybean,R.drawable.kitkat,R.drawable.lollipop};
    String name[]={"gingerbread","honeycomb","icecream","jellybean","kitkat","lollip[op"};


    public GridViewAdapter(Context context) {
        mcontext=context;
    }

    @Override
    public int getCount() {
        return image.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(mcontext).inflate(R.layout.grid,null);
       ImageView ivimage= (ImageView) convertView.findViewById(R.id.ivimage);
        TextView tvname=(TextView) convertView.findViewById(R.id.tvname);
        ivimage.setImageResource(image[position]);
        tvname.setText(name[position]);
        return convertView;

    }
}
